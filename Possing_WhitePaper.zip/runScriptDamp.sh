for j in 0.5 
do
  for i in 2
  do
    ./out ${i} 100 'd' ${j}
  done
done
